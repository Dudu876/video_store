/**
 * Created by Dudu on 03/05/2017.
 */
var myApp = angular.module('myApp', ['angucomplete-alt', 'simple-autocomplete', 'ui.bootstrap']);