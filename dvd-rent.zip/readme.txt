Running instructions:
npm install
bower install
npm start

The DB cennection info are located at con_data.json.